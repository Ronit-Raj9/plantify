package com.example.practice2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class result extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        TextView thanx =(TextView) findViewById(R.id.textView2);
        Intent intent =new Intent(result.this,MainActivity.class);
        startActivity(intent);
        //finish();
    }
}